#include "LineTracker.h"

void LineTracker_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(LINE_CLK, ENABLE);

    // 只初始化PB0 PB1 PB3 PB4 PB5 PB6 PB7，PB2悬空不配置
    GPIO_InitStructure.GPIO_Pin = SENSOR_1_PIN | SENSOR_2_PIN |
                                  SENSOR_3_PIN | SENSOR_4_PIN |
                                  SENSOR_5_PIN | SENSOR_6_PIN |
                                  SENSOR_7_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(LINE_PORT, &GPIO_InitStructure);
}

uint8_t LineTracker_GetData(void)
{
    uint8_t data = 0;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_1_PIN) == BLACK_LEVEL) data |= 0x01;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_2_PIN) == BLACK_LEVEL) data |= 0x02;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_3_PIN) == BLACK_LEVEL) data |= 0x04;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_4_PIN) == BLACK_LEVEL) data |= 0x08;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_5_PIN) == BLACK_LEVEL) data |= 0x10;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_6_PIN) == BLACK_LEVEL) data |= 0x20;
    if (GPIO_ReadInputDataBit(LINE_PORT, SENSOR_7_PIN) == BLACK_LEVEL) data |= 0x40;
    return data;
}

int8_t LineTracker_GetError(void)
{
    uint8_t data = LineTracker_GetData();
    if (data == 0x00)
        return 99;  // 全部无黑线，脱线

    int8_t sum = 0;
    uint8_t count = 0;
    // 7路权重：-12 -8 -4 0 4 8 12
    if (data & 0x01) { sum += -12; count++; }
    if (data & 0x02) { sum += -8;  count++; }
    if (data & 0x04) { sum += -4;  count++; }
    if (data & 0x08) { sum +=  0;  count++; }
    if (data & 0x10) { sum +=  4;  count++; }
    if (data & 0x20) { sum +=  8;  count++; }
    if (data & 0x40) { sum +=  12; count++; }

    if (count > 0)
        return (int8_t)(sum / count);
    return 0;
}

