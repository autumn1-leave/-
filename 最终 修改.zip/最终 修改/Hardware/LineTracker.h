#ifndef __LINETRACKER_H
#define __LINETRACKER_H

#include "stm32f10x.h"

#define LINE_PORT           GPIOB
#define LINE_CLK            RCC_APB2Periph_GPIOB

// 7路传感器，PB2完全不用
#define SENSOR_1_PIN        GPIO_Pin_0   // 最左
#define SENSOR_2_PIN        GPIO_Pin_1   // 左2
#define SENSOR_3_PIN        GPIO_Pin_3   // 左3（跳过PB2）
#define SENSOR_4_PIN        GPIO_Pin_4   // 中间
#define SENSOR_5_PIN        GPIO_Pin_5   // 右3
#define SENSOR_6_PIN        GPIO_Pin_6   // 右2
#define SENSOR_7_PIN        GPIO_Pin_7   // 最右

#define BLACK_LEVEL         1  // 黑线=高电平1，地面=0

void LineTracker_Init(void);
uint8_t LineTracker_GetData(void);
int8_t LineTracker_GetError(void);

#endif
