#include "Motor_A.h"

void Motor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_TIM1, ENABLE);

    // PWM引脚 PA8 PA9 复用推挽
    GPIO_InitStructure.GPIO_Pin = MOTOR_A_PWM_Pin | MOTOR_B_PWM_Pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 方向引脚 PA0 PA1 PA2 PA3
    GPIO_InitStructure.GPIO_Pin = MOTOR_A_IN1_Pin | MOTOR_A_IN2_Pin |
                                  MOTOR_B_IN1_Pin | MOTOR_B_IN2_Pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_ResetBits(GPIOA, MOTOR_A_IN1_Pin | MOTOR_A_IN2_Pin |
                          MOTOR_B_IN1_Pin | MOTOR_B_IN2_Pin);

    // TIM1 PWM配置
    TIM_TimeBaseStructure.TIM_Period = PWM_PERIOD;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM1, &TIM_OCInitStructure);
    TIM_OC2Init(TIM1, &TIM_OCInitStructure);

    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_Cmd(TIM1, ENABLE);
}

void Motor_SetSpeed(int16_t speed_left, int16_t speed_right)
{
    uint16_t pwm_val;
    // 左电机
    if (speed_left >= 0)
    {
        GPIO_SetBits(MOTOR_A_IN1_GPIO_Port, MOTOR_A_IN1_Pin);
        GPIO_ResetBits(MOTOR_A_IN2_GPIO_Port, MOTOR_A_IN2_Pin);
        pwm_val = (uint16_t)speed_left;
    }
    else
    {
        GPIO_ResetBits(MOTOR_A_IN1_GPIO_Port, MOTOR_A_IN1_Pin);
        GPIO_SetBits(MOTOR_A_IN2_GPIO_Port, MOTOR_A_IN2_Pin);
        pwm_val = (uint16_t)(-speed_left);
    }
    if (pwm_val > PWM_MAX_DUTY) pwm_val = PWM_MAX_DUTY;
    TIM_SetCompare1(TIM1, pwm_val);

    // 右电机
    if (speed_right >= 0)
    {
        GPIO_SetBits(MOTOR_B_IN1_GPIO_Port, MOTOR_B_IN1_Pin);
        GPIO_ResetBits(MOTOR_B_IN2_GPIO_Port, MOTOR_B_IN2_Pin);
        pwm_val = (uint16_t)speed_right;
    }
    else
    {
        GPIO_ResetBits(MOTOR_B_IN1_GPIO_Port, MOTOR_B_IN1_Pin);
        GPIO_SetBits(MOTOR_B_IN2_GPIO_Port, MOTOR_B_IN2_Pin);
        pwm_val = (uint16_t)(-speed_right);
    }
    if (pwm_val > PWM_MAX_DUTY) pwm_val = PWM_MAX_DUTY;
    TIM_SetCompare2(TIM1, pwm_val);
}

