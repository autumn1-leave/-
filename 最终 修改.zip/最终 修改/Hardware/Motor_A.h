#ifndef __MOTOR_A_H
#define __MOTOR_A_H

#include "stm32f10x.h"

// 左电机A
#define MOTOR_A_PWM_GPIO_Port   GPIOA
#define MOTOR_A_PWM_Pin         GPIO_Pin_8      // TIM1_CH1
#define MOTOR_A_IN1_GPIO_Port   GPIOA
#define MOTOR_A_IN1_Pin         GPIO_Pin_0
#define MOTOR_A_IN2_GPIO_Port   GPIOA
#define MOTOR_A_IN2_Pin         GPIO_Pin_1

// 右电机B
#define MOTOR_B_PWM_GPIO_Port   GPIOA
#define MOTOR_B_PWM_Pin         GPIO_Pin_9      // TIM1_CH2
#define MOTOR_B_IN1_GPIO_Port   GPIOA
#define MOTOR_B_IN1_Pin         GPIO_Pin_2
#define MOTOR_B_IN2_GPIO_Port   GPIOA
#define MOTOR_B_IN2_Pin         GPIO_Pin_3

#define PWM_PERIOD              3999
#define PWM_MAX_DUTY            3000

void Motor_Init(void);
void Motor_SetSpeed(int16_t speed_left, int16_t speed_right);

#endif
