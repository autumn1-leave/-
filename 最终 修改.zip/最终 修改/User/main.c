#include "stm32f10x.h"
#include "Motor_A.h"
#include "LineTracker.h"
#include "Delay.h"                  // Device header


// ================= 可调参数 =================
#define BASE_SPEED      2650    // 中间探头对准黑线时的基础直行速度
#define KP_NORMAL       70    // 轻微偏移修正系数
#define KP_SHARP        300     // 急弯大幅偏移修正系数

#define MAX_SPEED       2650
#define MIN_SPEED       -800    // 反转最大速度

// ================= 主函数 =================
int main(void)
{
    SystemInit();
    Motor_Init();
    LineTracker_Init();

    int base_speed = BASE_SPEED;
    int last_error = 0;
    int error = 0;
    int output = 0;
    int speed_left = 0;
    int speed_right = 0;
	Delay_s(1);
    while (1)
    {
        // 1. 获取7路传感器加权偏移误差
        error = LineTracker_GetError();

        // 2. 无黑线脱线：直接匀速直行，不原地打转
        if (error == 99)
        {
            Motor_SetSpeed(base_speed, base_speed);
            continue;
        }

        // 3. 缓存当前有效误差
        last_error = error;

        // 4. 分段比例P计算修正量（逻辑和原版完全一致）
        if (error == 0)
        {
            output = 0;  // 中间探头在黑线上，无修正，左右同速直行
        }
        else if (error == 1 || error == -1)
        {
			base_speed = 2600;
            output = error * KP_NORMAL; // 微小偏移，小力度微调
        }
        else if (error == 2 || error == -2)
        {
			base_speed = 2400;
            output = error * 100;       // 中等偏移
        }
        else
        {
			base_speed = 2300;
            output = error * KP_SHARP;  // 大偏移急弯，强力修正
        }

        // 5. 差速计算两轮速度
        speed_left = base_speed - output;
        speed_right = base_speed + output;

        // 6. 速度限幅保护
        if (speed_left > MAX_SPEED)  speed_left = MAX_SPEED;
        if (speed_left < MIN_SPEED)  speed_left = MIN_SPEED;
        if (speed_right > MAX_SPEED) speed_right = MAX_SPEED;
        if (speed_right < MIN_SPEED) speed_right = MIN_SPEED;

        // 7. 输出控制电机
        Motor_SetSpeed(speed_left, speed_right);
    }
}

